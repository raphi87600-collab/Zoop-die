# Zoopédie Android

Prototype Android en Kotlin + Jetpack Compose d'une encyclopédie animale immersive.

## V1
- Catalogue de 25+ espèces de démonstration
- Recherche par nom, nom scientifique, catégorie et régime
- Filtres par catégorie
- Fiches détaillées
- Favoris en mémoire
- Navigation Accueil / Explorer / Favoris
- Permission Internet prête pour la connexion future à une API

## À faire pour la version connectée
- API animale et cache local
- Images sous licences adaptées
- Données de conservation et répartition
- Persistance réelle des favoris
- Carte interactive

Ouvrir le dossier dans Android Studio puis lancer `Run` pour compiler et installer sur un appareil Android.

## Compilation APK dans le cloud avec GitHub Actions

Ce projet contient une compilation automatique dans `.github/workflows/build-apk.yml`.

1. Crée un nouveau dépôt GitHub.
2. Téléverse tous les fichiers de ce dossier (pas seulement le ZIP dans le dépôt : il faut extraire le ZIP puis importer son contenu).
3. Ouvre l'onglet **Actions** du dépôt et autorise les workflows si GitHub le demande.
4. Lance **Build Zoopedie APK** avec **Run workflow**, ou pousse le projet sur la branche `main`.
5. Attends la fin de la compilation puis ouvre le workflow terminé.
6. Télécharge l'artefact **Zoopedie-debug-APK**.
7. Dans l'archive téléchargée, récupère `app-debug.apk` et installe-le sur Android.

Le premier build peut prendre plusieurs minutes car GitHub doit télécharger les composants Android et Gradle.
